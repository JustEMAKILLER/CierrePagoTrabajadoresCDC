package sistemapagotrabajadorescdc;

public class Proyecto {
    private int numeroProyecto;
    private boolean esCertificado;
    private double horasTrab;
    private double horasExtra;

    public Proyecto(int numeroProyecto, boolean esCertificado, double horasTrab, double horasExtra) {
        this.numeroProyecto = numeroProyecto;
        this.esCertificado = esCertificado;
        this.horasTrab = horasTrab;
        this.horasExtra = horasExtra;
    }

    public double getHorasTrab() {
        return horasTrab;
    }

    public void setHorasTrab(double horasTrab) {
        this.horasTrab = horasTrab;
    }

    public double getHorasExtra() {
        return horasExtra;
    }

    public void setHorasExtra(double horasExtra) {
        this.horasExtra = horasExtra;
    }
    

    // Getters y setters
    public int getNumeroProyecto() {
        return numeroProyecto;
    }

    public void setNumeroProyecto(int numeroProyecto) {
        this.numeroProyecto = numeroProyecto;
    }

    public boolean isEsCertificado() {
        return esCertificado;
    }

    public void setEsCertificado(boolean esCertificado) {
        this.esCertificado = esCertificado;
    }

    void certificado() {
        System.out.print(esCertificado ? "Si" : "No");
    }
}