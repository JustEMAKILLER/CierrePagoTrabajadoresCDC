package sistemapagotrabajadorescdc;

import sistemapagotrabajadorescdc.utils.*;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

public class SistemaPagoTrabajadoresCDC {
    private static SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

    public static void main(String[] args) {
        // Cargar trabajadores al iniciar
        LinkedList<Trabajador> trabajadores = GestorPersistencia.cargarTrabajadores();
        boolean continuar = true;

        while (continuar) {
            System.out.println("\n=== SISTEMA DE PAGO POR RESULTADOS PARA SERVICIOS DE EXPORTACION (BARCO EXTRANJERO) - CDC S.A ===");
            System.out.println("""
                == Menu ==
                1- Mostrar trabajadores
                2- Mostrar informe de resumen
                3- Modificar trabajadores
                4- Historial de cambios
                5- Guardar
                6- Guardar y salir""");
            
            int seleccion = Lectura.leerEnteroEnRango("Seleccione una opcion (1-6): ", 1, 6);
            
            switch(seleccion) {
                case 1:
                    mostrarTrabajadores(trabajadores);
                    break;
                case 2:
                    mostrarResumenTrabajadores(trabajadores);
                    break;
                case 3:
                    menuModificacion(trabajadores);
                    break;
                case 4:
                    RegistroCambios.mostrarHistorial();
                    break;
                case 5:
                    GestorPersistencia.guardarTrabajadores(trabajadores);
                    break;
                case 6:
                    // Guardar antes de salir
                    GestorPersistencia.guardarTrabajadores(trabajadores);
                    continuar = false;
            }
        }
    }

    private static void menuModificacion(LinkedList<Trabajador> trabajadores) {
        System.out.println("""
            \n== Modificar Trabajadores ==
            1- Agregar trabajador
            2- Modificar trabajador
            3- Eliminar trabajador
            4- Volver al menu principal""");
        
        int opcion = Lectura.leerEnteroEnRango("Seleccione una opcion (1-4): ", 1, 4);
        
        switch(opcion) {
            case 1:
                agregarTrabajador(trabajadores);
                break;
            case 2:
                modificarTrabajador(trabajadores);
                break;
            case 3:
                eliminarTrabajador(trabajadores);
                break;
            case 4:
                return;
        }
    }

    private static void agregarTrabajador(LinkedList<Trabajador> trabajadores) {
        System.out.println("\n== Agregar Trabajador ==");
        System.out.print("Ingrese Departamento del trabajador: ");
        String depto = Lectura.sc.nextLine();
        
        int codigo = Lectura.leerCodigoUnico(trabajadores, "Ingrese Codigo del trabajador: ");
        
        System.out.print("Ingrese Nombre y Apellidos del trabajador: ");
        String nombre = Lectura.sc.nextLine();
        
        System.out.print("Ingrese el Cargo del trabajador: ");
        String cargo = Lectura.sc.nextLine();
        
        int grupoEscala = Lectura.leerEntero("Ingrese Grupo Escala del trabajador: ");
        Lectura.sc.nextLine(); // Limpiar buffer
        
        System.out.print("Ingrese la Ocupacion Barco del trabajador: ");
        String ocupBarco = Lectura.sc.nextLine();
        
        ArrayList<Proyecto> proyectos = new ArrayList<>();
        int cantProyectos =  Lectura.leerEntero("Ingrese la cantidad de proyectos: ");
        Lectura.sc.nextLine(); // Limpiar buffer
        for (int i = 1; i <= cantProyectos; i++) {
            int numProyecto = Lectura.leerEntero("Ingrese el numero del proyecto #" + i + ": ");
            Lectura.sc.nextLine(); // Limpiar buffer
            
            boolean esCertificado = Lectura.leerSiNo("El proyecto esta certificado? (S/N): ");
            
            double cantHorasTrab = Lectura.leerDouble("Ingrese horas trabajadas del proyecto " + numProyecto + ": ");
            double cantHorasExtra = Lectura.leerDouble("Ingrese horas extra del proyecto " + numProyecto + ": ");
            Lectura.sc.nextLine(); // Limpiar buffer
        
            proyectos.add(new Proyecto(numProyecto, esCertificado, cantHorasTrab, cantHorasExtra));
        }
        
        boolean esBaja = Lectura.leerSiNo("El trabajador es baja? (S/N): ");
        
        boolean tieneClave271 = false;
        boolean tieneClave269 = false;
        boolean tieneClave278 = false;
        
        if (Lectura.leerSiNo("El trabajador tiene claves? (S/N): ")) {
            int cantClaves =  Lectura.leerEntero("Cuantas claves?: ");
            Lectura.sc.nextLine(); //Limpiar buffer
            System.out.println("Ingrese las claves (269, 271 o 278):");
            for (int i = 0; i < cantClaves; i++) {
               int clave = Lectura.leerClave("Clave " + (i+1) + ": ");
                if (clave == 269) tieneClave269 = true;
                else if (clave == 271) tieneClave271 = true;
                else if (clave == 278) tieneClave278 = true;
            }
            Lectura.sc.nextLine(); //Limpiar buffer
        }
        
        Trabajador nuevo = new Trabajador(grupoEscala, cargo, 
                                         depto, codigo, nombre, ocupBarco, proyectos, 
                                         esBaja, tieneClave271, tieneClave278, tieneClave269);
        nuevo.setFechaUltimaModificacion(dateFormat.format(new Date()));
        trabajadores.add(nuevo);
        System.out.println("Trabajador " + nombre +" agregado exitosamente.");
        
        // Guardar automáticamente después de agregar
        GestorPersistencia.guardarTrabajadores(trabajadores);
        
        RegistroCambios.registrarCambio("ALTA", codigo, 
            "Nuevo trabajador: " + nombre + " - Depto: " + depto);
    }

    private static void modificarTrabajador(LinkedList<Trabajador> trabajadores) {
        if (trabajadores.isEmpty()) {
            System.out.println("Error: No hay trabajadores registrados en el sistema.");
            return;
        }
        
        int codigo = Lectura.leerEntero("Ingrese el codigo del trabajador a modificar: ");
        Lectura.sc.nextLine(); // Limpiar buffer
        
        Trabajador trabajador = trabajadores.stream()
            .filter(t -> t.getCodigo() == codigo)
            .findFirst()
            .orElse(null);
        
        if (trabajador == null) {
            System.out.println("No se encontro trabajador con el codigo " + codigo + ".");
            return;
        }

        System.out.println("Trabajador seleccionado: " + trabajador.getNombre());
        System.out.println("""
            Seleccione atributo a modificar:
            1- Departamento
            2- Nombre
            3- Cargo
            4- Grupo Escala
            5- Ocupacion Barco
            6- Proyectos
            7- Estado de baja
            8- Claves
            9- Cancelar""");
        
        int opcion = Lectura.leerEnteroEnRango("Seleccione una opcion (1-9): ", 1, 9);
        
        switch(opcion) {
            case 1:
                System.out.print("\n== Modificar Departamento ==\nNuevo departamento: ");
                trabajador.setDepto(Lectura.sc.nextLine());
                RegistroCambios.registrarCambio("MODIFICACION", codigo, 
                    "Cambio de departamento a: " + trabajador.getDepto());
                break;
            case 2:
                System.out.print("\n== Modificar Nombre ==\nNuevo nombre: ");
                trabajador.setNombre(Lectura.sc.nextLine());
                RegistroCambios.registrarCambio("MODIFICACION", codigo, 
                    "Cambio de nombre a: " + trabajador.getNombre());
                break;
            case 3:
                System.out.print("\n== Modificar Cargo ==\nNuevo cargo: ");
                trabajador.setCargo(Lectura.sc.nextLine());
                RegistroCambios.registrarCambio("MODIFICACION", codigo, 
                    "Cambio de cargo a: " + trabajador.getCargo());
                break;
            case 4:
                int nuevoGrupo = Lectura.leerEntero("\n== Modificar Grupo Escala ==\nNuevo Grupo Escala");
                Lectura.sc.nextLine(); // Limpiar buffer
                trabajador.setGrupoEscala(nuevoGrupo);
                trabajador.setTarifa(trabajador.calcularTarifa(trabajador.getGrupoEscala(), trabajador.getOcupBarco()));
                RegistroCambios.registrarCambio("MODIFICACION", codigo, 
                    "Cambio de Grupo Escala a: " + trabajador.getGrupoEscala());
                break;
            case 5:
                System.out.print("\n== Modificar Ocupacion Barco ==\nNueva Ocupacion Barco: ");
                trabajador.setOcupBarco(Lectura.sc.nextLine());
                RegistroCambios.registrarCambio("MODIFICACION", codigo, 
                    "Cambio de Ocupacion Barco a: " + trabajador.getOcupBarco());
                break;
            case 6:
                modificarProyectos(trabajador);
                break;
            case 7:
                trabajador.setEsBaja(Lectura.leerSiNo("\n== Modificar Estado de baja ==\nEs baja? (S/N): "));
                RegistroCambios.registrarCambio("MODIFICACION", codigo, 
                    "Cambio de estado de baja a: " + (trabajador.isEsBaja() ? "Sí" : "No"));
                break;
            case 8:
                menuModificacionClaves(trabajador, codigo);
                break;
            case 9:
                return;
        }
        
        // Después de cada modificación exitosa:
        trabajador.setFechaUltimaModificacion(dateFormat.format(new Date()));
        System.out.println("Modificacion realizada exitosamente.");
        
        // Guardar automáticamente después de modificar
        GestorPersistencia.guardarTrabajadores(trabajadores);
    }
    
    private static void eliminarTrabajador(LinkedList<Trabajador> trabajadores) {
        if (trabajadores.isEmpty()) {
            System.out.println("Error:  No hay trabajadores registrados en el sistema.");
            return;
        }
        System.out.println("\n== Eliminar Trabajador ==");
        int codigo = Lectura.leerEntero("Ingrese el codigo del trabajador a eliminar: ");
        Lectura.sc.nextLine(); // Limpiar buffer
        
        String nombreTrab = trabajadores.stream()
            .filter(t -> t.getCodigo() == codigo)
            .findFirst()
            .map(Trabajador::getNombre)
            .orElse("");
        
        if (!nombreTrab.equals("")){
      System.out.println("El codigo introducido pertenece a " + nombreTrab);
        boolean eliminar = Lectura.leerSiNo("Esta seguro de eliminar? (S/N): ");
        if (eliminar){
        boolean eliminado = trabajadores.removeIf(t -> t.getCodigo() == codigo);
        
        if (eliminado) {
            System.out.println(nombreTrab + " ha sido removido del sistema exitosamente.");
            RegistroCambios.registrarCambio("BAJA", codigo, 
                "Trabajador eliminado del sistema.");
            // Guardar automáticamente después de eliminar
            GestorPersistencia.guardarTrabajadores(trabajadores);
        }
        }
        }
        else {
            System.out.println("Error: No se encontro trabajador con el codigo " + codigo + ".");
            return;
        }
    }

    private static void menuModificacionClaves(Trabajador trabajador, int codigo) {
    boolean continuar = true;
    
    while (continuar) {
        System.out.println("""
            --- MODIFICACION DE CLAVES ---
            Claves actuales:
            269: """ + (trabajador.getCantidadClaves269() > 0 ? "Sí (" + trabajador.getCantidadClaves269() + ") " : "No ") + """
            | 271: """ + (trabajador.isTieneClave271() ? "Sí " : "No ") + """
            | 278: """ + (trabajador.isTieneClave278() ? "Sí" : "No") + """
            
            Seleccione clave a modificar:
            1- 269
            2- 271
            3- 278
            4- Volver""");
        
        int opcion = Lectura.leerEnteroEnRango("Seleccione una opcion (1-4): ", 1, 4);
        
        switch(opcion) {
            case 1: // Clave 269
                System.out.print("Agregar (A) o quitar (Q) clave 269?: ");
                String accion = Lectura.sc.nextLine().toUpperCase();
                if (accion.equals("A")) {
                    trabajador.agregarClave269();
                    System.out.println("Clave 269 agregada. Total: " + trabajador.getCantidadClaves269());
                    RegistroCambios.registrarCambio("MODIFICACION", codigo, 
                        "Clave 269 agregada. Total: " + trabajador.getCantidadClaves269());
                } else if (accion.equals("Q") && trabajador.getCantidadClaves269() > 0) {
                    trabajador.setCantidadClaves269(trabajador.getCantidadClaves269() - 1);
                    System.out.println("Clave 269 removida. Total: " + trabajador.getCantidadClaves269());
                    RegistroCambios.registrarCambio("MODIFICACION", codigo, 
                        "Clave 269 removida. Total: " + trabajador.getCantidadClaves269());
                } else {
                    System.out.println("Operacion no valida o no hay claves 269 para quitar.");
                }
                break;
                
            case 2: // Clave 271
                boolean nuevoEstado271 = Lectura.leerSiNo("Activar clave 271? (S/N): ");
                if (trabajador.isTieneClave271() != nuevoEstado271) {
                    trabajador.setTieneClave271(nuevoEstado271);
                    System.out.println("Clave 271 " + (nuevoEstado271 ? "activada" : "desactivada"));
                    RegistroCambios.registrarCambio("MODIFICACION", codigo, 
                        "Clave 271 cambiada a " + (nuevoEstado271 ? "activa" : "inactiva"));
                }
                break;
                
            case 3: // Clave 278
                boolean nuevoEstado278 = Lectura.leerSiNo("Activar clave 278? (S/N): ");
                if (trabajador.isTieneClave278() != nuevoEstado278) {
                    trabajador.setTieneClave278(nuevoEstado278);
                    System.out.println("Clave 278 " + (nuevoEstado278 ? "activada" : "desactivada"));
                    RegistroCambios.registrarCambio("MODIFICACION", codigo, 
                        "Clave 278 cambiada a " + (nuevoEstado278 ? "activa" : "inactiva"));
                }
                break;
                
            case 4:
                continuar = false;
                break;
        }
    }
}
    private static void modificarProyectos(Trabajador trabajador) {
        boolean continuarModificacion = true;
        
        while (continuarModificacion) {
            System.out.println("\n--- Gestion de Proyectos ---");
            System.out.println("Proyectos actuales de " + trabajador.getNombre() + ":");
            trabajador.mostrarProyectos();
            
            System.out.println("""
                \nSeleccione una opcion:
                1- Agregar nuevo proyecto
                2- Eliminar proyecto existente
                3- Modificar certificacion de proyecto
                4- Modificar horas trabajadas de proyecto
                5- Modificar horas extra de proyecto
                6- Volver al menu anterior""");
            
            int opcionProyectos = Lectura.leerEnteroEnRango("Seleccione una opcion (1-6): ", 1, 6);
            
            switch(opcionProyectos) {
                case 1:
                    int nuevoNumProyecto = Lectura.leerEntero("Ingrese el numero del nuevo proyecto: ");
                    Lectura.sc.nextLine(); // Limpiar buffer
                    
                    boolean certificado = Lectura.leerSiNo("El proyecto esta certificado (S/N): ");
                    double cantHorasTrab = Lectura.leerDouble("Ingrese horas trabajadas del proyecto: ");
                    double cantHorasExtra = Lectura.leerDouble("Ingrese horas extra del proyecto: ");
                    Lectura.sc.nextLine(); // Limpiar buffer
            
                    trabajador.getProyectos().add(new Proyecto(nuevoNumProyecto, certificado, cantHorasTrab, cantHorasExtra));
                    System.out.println("Proyecto " + nuevoNumProyecto + " agregado exitosamente.");
                    break;
                    
                case 2:
                    if (trabajador.getProyectos().isEmpty()) {
                        System.out.println(trabajador.getNombre() + " no tiene proyectos para eliminar.");
                        break;
                    }
                    
                    int numProyectoEliminar = Lectura.leerEntero("Ingrese el numero del proyecto a eliminar: ");
                    Lectura.sc.nextLine(); // Limpiar buffer
                    
                    boolean eliminado = trabajador.getProyectos().removeIf(p -> p.getNumeroProyecto() == numProyectoEliminar);
                    
                    if (eliminado) {
                        System.out.println("Proyecto " + numProyectoEliminar + " eliminado exitosamente.");
                    } else {
                        System.out.println("No se encontro ningun proyecto con ese numero.");
                    }
                    break;
                    
                case 3:
                    if (trabajador.getProyectos().isEmpty()) {
                        System.out.println("El trabajador no tiene proyectos para modificar.");
                        break;
                    }
                    
                    int numProyectoModificar = Lectura.leerEntero("Ingrese el numero del proyecto a modificar: ");
                    Lectura.sc.nextLine(); // Limpiar buffer
                    
                    Proyecto proyectoAModificar = trabajador.getProyectos().stream()
                        .filter(p -> p.getNumeroProyecto() == numProyectoModificar)
                        .findFirst()
                        .orElse(null);
                    
                    if (proyectoAModificar != null) {
                        boolean nuevoEstado = Lectura.leerSiNo("El proyecto esta certificado? (Actualmente: " + 
                                       (proyectoAModificar.isEsCertificado() ? "Sí" : "No") + ") (S/N): ");
                        proyectoAModificar.setEsCertificado(nuevoEstado);
                        System.out.println("Certificacion del proyecto " + numProyectoModificar + " actualizada exitosamente.");
                    } else {
                        System.out.println("Error: No se encontro proyecto con el numero " + numProyectoModificar + ".");
                    }
                    break;
                    
                case 4:
                    if (trabajador.getProyectos().isEmpty()) {
                        System.out.println(trabajador.getNombre() + " no tiene proyectos para modificar.");
                        break;
                    }
                    
                    int numProyectoHoras = Lectura.leerEntero("Ingrese el numero del proyecto a modificar: ");
                    Lectura.sc.nextLine(); // Limpiar buffer
                    
                    Proyecto proyectoHoras = trabajador.getProyectos().stream()
                        .filter(p -> p.getNumeroProyecto() == numProyectoHoras)
                        .findFirst()
                        .orElse(null);
                    
                    if (proyectoHoras != null) {
                        double nuevasHoras = Lectura.leerDouble("Ingrese nuevas horas trabajadas: ");
                        Lectura.sc.nextLine(); // Limpiar buffer
                        proyectoHoras.setHorasTrab(nuevasHoras);
                        System.out.println("Horas trabajadas del proyecto " + numProyectoHoras + " actualizadas exitosamente.");
                    } else {
                        System.out.println("Error: No se encontro proyecto con ese numero.");
                    }
                    break;
                    
                case 5:
                    if (trabajador.getProyectos().isEmpty()) {
                        System.out.println(trabajador.getNombre() + " no tiene proyectos para modificar.");
                        break;
                    }
                    
                    int numProyectoExtra = Lectura.leerEntero("Ingrese el numero del proyecto a modificar: ");
                    Lectura.sc.nextLine(); // Limpiar buffer
                    
                    Proyecto proyectoExtra = trabajador.getProyectos().stream()
                        .filter(p -> p.getNumeroProyecto() == numProyectoExtra)
                        .findFirst()
                        .orElse(null);
                    
                    if (proyectoExtra != null) {
                        double nuevasExtra = Lectura.leerDouble("Ingrese nuevas horas extra: ");
                        Lectura.sc.nextLine(); // Limpiar buffer
                        proyectoExtra.setHorasExtra(nuevasExtra);
                        System.out.println("Horas extra del proyecto " + numProyectoExtra + " actualizadas exitosamente.");
                    } else {
                        System.out.println("Error: No se encontro proyecto con ese numero.");
                    }
                    break;
                    
                case 6:
                    continuarModificacion = false;
                    break;
            }
        }
    }
    
    private static void mostrarTrabajadores(LinkedList<Trabajador> trabajadores) {
        if (trabajadores.isEmpty()) {
            System.out.println("Error:  No hay trabajadores registrados en el sistema.");
            return;
        }
        
        System.out.println("\n=== SISTEMA DE PAGO POR RESULTADOS PARA SERVICIOS DE EXPORTACION (BARCO EXTRANJERO) - CDC S.A ===");
        
        // Agrupar por departamento
        Map<String, List<Trabajador>> trabajadoresPorDepto = new TreeMap<>();
        for (Trabajador t : trabajadores) {
            trabajadoresPorDepto
                .computeIfAbsent(t.getDepto(), k -> new ArrayList<>())
                .add(t);
        }

        // Mostrar por departamento
        for (Map.Entry<String, List<Trabajador>> entry : trabajadoresPorDepto.entrySet()) {
            String departamento = entry.getKey();
            List<Trabajador> trabajadoresDepto = entry.getValue();

            System.out.println("\n============================================");
            System.out.println(" DEPARTAMENTO: " + departamento.toUpperCase());
            System.out.println("============================================");

            // Separar con/sin derecho
            List<Trabajador> sinDerecho = new ArrayList<>();
            List<Trabajador> conDerecho = new ArrayList<>();

            for (Trabajador t : trabajadoresDepto) {
                if (t.tieneDerechoACobro()) conDerecho.add(t);
                else sinDerecho.add(t);
            }

            // Mostrar sin derecho
            System.out.println("\n=== TRABAJADORES SIN DERECHO A COBRO ===");
            if (sinDerecho.isEmpty()) {
                System.out.println("No hay trabajadores sin derecho a cobro.");
            } else {
                sinDerecho.forEach(t -> {
                    t.mostrarInformacionCompleta();
                    t.mostrarEstadoPago();
                });
            }

            // Mostrar con derecho
            System.out.println("\n=== TRABAJADORES CON DERECHO A COBRO ===");
            if (conDerecho.isEmpty()) {
                System.out.println("No hay trabajadores con derecho a cobro.");
            } else {
                conDerecho.forEach(t -> {
                    t.mostrarInformacionCompleta();
                    t.mostrarEstadoPago();
                });
            }
        }
    }
    
    private static void mostrarResumenTrabajadores(LinkedList<Trabajador> trabajadores) {
        if (trabajadores.isEmpty()) {
            System.out.println("No hay trabajadores registrados en el sistema.");
            return;
        }

        // Inicialización de contadores
        int totalConDerecho = 0;
        int totalSinDerecho = 0;
        double montoTotalConDerecho = 0, montoTotalSinDerecho = 0;
        LinkedList<Trabajador> trabajadoresConDerecho = new LinkedList<>();
        LinkedList<Trabajador> trabajadoresSinDerecho = new LinkedList<>();

        // Clasificación de trabajadores
        for (Trabajador t : trabajadores) {
            if (t.tieneDerechoACobro()) {
                trabajadoresConDerecho.add(t);
                totalConDerecho++;
                montoTotalConDerecho += t.getPagoTotal();
            } else {
                trabajadoresSinDerecho.add(t);
                totalSinDerecho++;
                montoTotalSinDerecho += t.getPagoTotal();
            }
        }

        System.out.println("\n=== SISTEMA DE PAGO POR RESULTADOS PARA SERVICIOS DE EXPORTACION (BARCO EXTRANJERO) - CDC S.A ===");
        
        // Mostrar resumen con derecho
        System.out.println("\n==========================================================================");
        System.out.println(" RESUMEN DE TRABAJADORES CON DERECHO A COBRO");
        System.out.println("==========================================================================");
        System.out.println("Total: " + totalConDerecho);
        
        if (trabajadoresConDerecho.isEmpty()) {
            System.out.println("No hay trabajadores con derecho a cobro en el sistema.");
        } else {
            trabajadoresConDerecho.forEach(t -> {
                System.out.println("- " + t.getNombre() + 
                    " (Codigo: " + t.getCodigo() + 
                    ") | Depto: " + t.getDepto() + 
                    " | Pago total: " + t.getPagoTotal() + " CUP");
                t.mostrarProyectosNoCertificados();
            });
            System.out.println("Total Barco Extranjero: " + montoTotalConDerecho + " CUP");
        }

        // Mostrar resumen sin derecho
        System.out.println("\n==========================================================================");
        System.out.println(" RESUMEN DE TRABAJADORES SIN DERECHO A COBRO");
        System.out.println("==========================================================================");
        System.out.println("Total: " + totalSinDerecho);
        
        if (trabajadoresSinDerecho.isEmpty()) {
            System.out.println("No hay trabajadores sin derecho a cobro en el sistema.");
        } else {
            trabajadoresSinDerecho.forEach(t -> {
                System.out.println("- " + t.getNombre() + 
                    " (Codigo: " + t.getCodigo() + 
                    ") | Depto: " + t.getDepto());
                t.mostrarProyectos();
                t.mostrarEstadoPago();  
            });
            System.out.println("Total no pagable: " + montoTotalSinDerecho + " CUP");
        }
        System.out.println("==========================================================================");
        System.out.println("Cantidad total de trabajadores: " + (totalConDerecho + totalSinDerecho) + 
            "\nMonto total de todos los trabajadores: " + (montoTotalConDerecho + montoTotalSinDerecho) + " CUP");
    }
    
}