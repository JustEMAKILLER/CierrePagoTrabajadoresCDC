package sistemapagotrabajadorescdc.utils;

import java.io.*;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedList;
import sistemapagotrabajadorescdc.Proyecto;
import sistemapagotrabajadorescdc.Trabajador;

public class GestorPersistencia {
    private static final String ARCHIVO_DATOS = "trabajadores.dat";
    private static final SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

    public static void guardarTrabajadores(LinkedList<Trabajador> trabajadores) {
        try (PrintWriter writer = new PrintWriter(new FileWriter(ARCHIVO_DATOS))) {
            for (Trabajador t : trabajadores) {
                writer.println(serializarTrabajador(t));
            }
            System.out.println("Datos guardados correctamente");
        } catch (IOException e) {
            System.err.println("Error al guardar los datos: " + e.getMessage());
        }
    }

    public static LinkedList<Trabajador> cargarTrabajadores() {
        LinkedList<Trabajador> trabajadores = new LinkedList<>();
        File archivo = new File(ARCHIVO_DATOS);
        
        if (!archivo.exists()) {
            return trabajadores;
        }

        try (BufferedReader reader = new BufferedReader(new FileReader(ARCHIVO_DATOS))) {
            String linea;
            while ((linea = reader.readLine()) != null) {
                Trabajador t = deserializarTrabajador(linea);
                if (t != null) {
                    trabajadores.add(t);
                }
            }
            System.out.println("Datos cargados correctamente");
        } catch (IOException e) {
            System.err.println("Error al cargar los datos: " + e.getMessage());
        }
        return trabajadores;
    }

    //Serializar Trabajador
    private static String serializarTrabajador(Trabajador t) {
        StringBuilder sb = new StringBuilder();
        sb.append(t.getCodigo()).append("|");
        sb.append(t.getNombre()).append("|");
        sb.append(t.getDepto()).append("|");
        sb.append(t.getCargo()).append("|");
        sb.append(t.getGrupoEscala()).append("|");
        sb.append(t.getOcupBarco()).append("|");
        sb.append(t. hallarCantTotalHTrab()).append("|");
        sb.append(t.hallarCantTotalHExtra()).append("|");
        sb.append(t.isEsBaja()).append("|");
        sb.append(t.isTieneClave269()).append("|");
        sb.append(t.isTieneClave271()).append("|");
        sb.append(t.isTieneClave278()).append("|");
        sb.append(dateFormat.format(new Date())).append("|"); // Marca de tiempo
        
        // Serializar proyectos
        sb.append("[");
        for (Proyecto p : t.getProyectos()) {
            sb.append(p.getNumeroProyecto()).append(",");
            sb.append(p.isEsCertificado()).append(";");
        }
        sb.append("]");
        
        return sb.toString();
    }

        //Deserializar Trabajador
    private static Trabajador deserializarTrabajador(String linea) {
        try {
            String[] partes = linea.split("\\|", -1);
            
            int codigo = Integer.parseInt(partes[0]);
            String nombre = partes[1];
            String depto = partes[2];
            String cargo = partes[3];
            int grupoEscala = Integer.parseInt(partes[4]);
            String ocupBarco = partes[5];
            double horasTrab = Double.parseDouble(partes[6]);
            double horasExtra = Double.parseDouble(partes[7]);
            boolean esBaja = Boolean.parseBoolean(partes[8]);
            boolean clave269 = Boolean.parseBoolean(partes[9]);
            boolean clave271 = Boolean.parseBoolean(partes[10]);
            boolean clave278 = Boolean.parseBoolean(partes[11]);
            String fechaModificacion = partes[12];
            
            // Deserializar proyectos
            ArrayList<Proyecto> proyectos = new ArrayList<>();
            String proyectosStr = partes[13].substring(1, partes[13].length() - 1);
            if (!proyectosStr.isEmpty()) {
                String[] proyectosArray = proyectosStr.split(";");
                for (String p : proyectosArray) {
                    if (!p.isEmpty()) {
                        String[] datosProyecto = p.split(",");
                        int numProyecto = Integer.parseInt(datosProyecto[0]);
                        boolean certificado = Boolean.parseBoolean(datosProyecto[1]);
                        proyectos.add(new Proyecto(numProyecto, certificado, horasTrab,  horasExtra));
                    }
                }
            }
            
            Trabajador t = new Trabajador(grupoEscala, cargo, depto, 
                                         codigo, nombre, ocupBarco, proyectos, esBaja, 
                                         clave271, clave278, clave269);
            return t;
        } catch (Exception e) {
            System.err.println("Error al deserializar trabajador: " + e.getMessage());
            return null;
        }
    }
}