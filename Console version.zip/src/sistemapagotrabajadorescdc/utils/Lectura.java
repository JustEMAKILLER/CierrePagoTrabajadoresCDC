
package sistemapagotrabajadorescdc.utils;

import java.util.InputMismatchException;
import java.util.LinkedList;
import java.util.Scanner;
import sistemapagotrabajadorescdc.Trabajador;

public class Lectura {
    public static Scanner sc = new Scanner(System.in);
    
        // Métodos auxiliares para validación de entradas
    public static int leerEntero(String mensaje) {
        while (true) {
            try {
                System.out.print(mensaje);
                int numero = sc.nextInt();
                if (numero < 0) {
                    throw new IllegalArgumentException("El numero debe ser positivo."); 
                }
                return numero;
            } catch (InputMismatchException e) {
                System.out.println("Error: Debe ingresar un numero entero valido.");
                sc.nextLine(); // Limpia el buffer
            } catch (IllegalArgumentException e) {
                System.out.println("Error: " + e.getMessage()); 
        }
    }
    }

    public static double leerDouble(String mensaje) {
        while (true) {
            try {
                System.out.print(mensaje);
                int numero = sc.nextInt();
                if (numero < 0) {
                    throw new IllegalArgumentException("El numero debe ser positivo."); 
                }
                return numero;
            } catch (InputMismatchException e) {
                System.out.println("Error: Debe ingresar un numero valido.");
                sc.nextLine(); // Limpiar el buffer
            }
            catch(IllegalArgumentException e){
                System.out.println("Error: " + e.getMessage()); 
            }
        }
    }

    public static int leerEnteroEnRango(String mensaje, int min, int max) {
        while (true) {
            try{
            int valor = leerEntero(mensaje);
            if (valor >= min && valor <= max) {
                sc.nextLine(); // Limpiar buffer
                return valor;
            }
            else {
                throw new IllegalArgumentException("Error: El valor de la seleccion debe estar entre " + min + " y " + max + ".");
            }
            }
            catch(IllegalArgumentException e){
                    System.out.println("Error: " + e.getMessage());
                    }
        }
    }

    public static boolean leerSiNo(String mensaje) {
        while (true) {
            try{
            System.out.print(mensaje);
            String respuesta = sc.nextLine().trim().toUpperCase();
            if (respuesta.equals("S") || respuesta.equals("N")) {
                return respuesta.equals("S");
            }
            else {
                throw new InputMismatchException("Debe ingresar 'S' o 'N'.");
            }
            }
            catch (InputMismatchException e){
                    System.out.println("Error: " + e.getMessage());
                    }
        }
    }

    public static int leerCodigoUnico(LinkedList<Trabajador> trabajadores, String mensaje) {
        while (true) {
            int codigo = leerEntero(mensaje);
            sc.nextLine(); // Limpiar buffer
            boolean existe = trabajadores.stream().anyMatch(t -> t.getCodigo() == codigo);
            
            if (!existe) {
                return codigo;
            }
            System.out.println("Error: Ya existe un trabajador con ese codigo. Intente nuevamente.");
        }
    }
    
public static int leerClave(String mensaje) {
    while (true) {
        try {
            System.out.print(mensaje);
            int clave = sc.nextInt();
            sc.nextLine(); // Limpiar buffer
            
            if (clave == 269 || clave == 271 || clave == 278) {
                return clave;
            } else {
                System.out.println("Error: Las claves validas son solamente 269, 271 y 278.");
            }
        } catch (InputMismatchException e) {
            System.out.println("Error: Debe ingresar un numero entero valido.");
            sc.nextLine(); // Limpiar buffer
        }
    }
}
}
