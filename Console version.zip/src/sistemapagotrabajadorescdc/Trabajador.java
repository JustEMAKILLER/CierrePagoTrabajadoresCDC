package sistemapagotrabajadorescdc;

import java.util.ArrayList;

public class Trabajador {
    private String fechaUltimaModificacion = "No modificado aun";
    private int grupoEscala;
    private int tarifa;
    private double pagoTotalHTrab;
    private double pagoTotalHExtra;
    private double pagoTotal;
    private String cargo;
    private String depto;
    private int codigo;
    private String nombre;
    private String ocupBarco;
    private ArrayList<Proyecto> proyectos;
    private boolean esBaja;
    private boolean tieneClave271;
    private boolean tieneClave269;

    public double getPagoTotalHTrab() {
        return pagoTotalHTrab;
    }

    public void setPagoTotalHTrab(double pagoTotalHTrab) {
        this.pagoTotalHTrab = pagoTotalHTrab;
    }

    public double getPagoTotalHExtra() {
        return pagoTotalHExtra;
    }

    public void setPagoTotalHExtra(double pagoTotalHExtra) {
        this.pagoTotalHExtra = pagoTotalHExtra;
    }
    private int cantidadClaves269;
    private boolean tieneClave278;

    public Trabajador(int grupoEscala, String cargo, String depto, 
                     int codigo, String nombre, String ocupBarco, ArrayList<Proyecto> proyectos, 
                     boolean esBaja, boolean tieneClave271, boolean tieneClave278, boolean tieneClave269) {
        this.grupoEscala = grupoEscala;
        this.cargo = cargo;
        this.depto = depto;
        this.codigo = codigo;
        this.nombre = nombre;
        this.ocupBarco = ocupBarco;
        this.proyectos = proyectos != null ? new ArrayList<>(proyectos) : new ArrayList<>();
        this.esBaja = esBaja;
        this.tieneClave271 = tieneClave271;
        this.tieneClave269 = tieneClave269;
        this.cantidadClaves269 = tieneClave269 ? 1 : 0;
        this.tieneClave278 = tieneClave278;
        this.tarifa = calcularTarifa(grupoEscala, ocupBarco);
        this.pagoTotalHTrab = calcularPagoTotalHTrab();
        this.pagoTotalHExtra = calcularPagoTotalHExtra();
        this.pagoTotal = calcularPagoTotal();
        
    }

// Método para verificar derecho a cobro
    public boolean tieneDerechoACobro() {
        // No tiene derecho si está de baja
        if (this.esBaja) {
            return false;
        }
        
        // No tiene derecho si tiene alguna clave 271 o 278
        if (this.tieneClave271 || this.tieneClave278) {
            return false;
        }
        
        // Para la clave 269, necesita tener 2 o más
        if (this.cantidadClaves269 >= 2) {
            return false;
        }
        
        return true;
    }
    
        // Método para mostrar estado de pago
    public void mostrarEstadoPago() {
        if (!tieneDerechoACobro()) {
            System.out.println("El trabajador NO tiene derecho a cobro");
            System.out.println("Motivos:");
            
            if (this.esBaja) {
                System.out.println("- Esta dado de baja");
            }
            
            if (this.tieneClave271) {
                System.out.println("- Tiene clave 271");
            }
            
            if (this.tieneClave278) {
                System.out.println("- Tiene clave 278");
            }
            
            if (this.cantidadClaves269 >= 2) {
                System.out.println("- Tiene " + this.cantidadClaves269 + " claves 269");
            }
        } else {
            System.out.println("El trabajador tiene derecho a cobro");
        }
            System.out.println("---------------------------");
    }

    public int getCantidadClaves269() {
        return cantidadClaves269;
    }

public void setCantidadClaves269(int cantidad) {
    this.cantidadClaves269 = cantidad;
    this.tieneClave269 = cantidad > 0;
}
    
    // Método para agregar claves 269
    public void agregarClave269() {
        this.cantidadClaves269++;
        this.tieneClave269 = true;
    }
    
    int calcularTarifa(int grupoEscala, String ocupBarco) {
        if (grupoEscala == 2 && "D".equalsIgnoreCase(ocupBarco)) return 35;
        if (grupoEscala == 4 && "D".equalsIgnoreCase(ocupBarco)) return 37;
        if (grupoEscala == 5 && "D".equalsIgnoreCase(ocupBarco)) return 38;
        if (grupoEscala == 6 && "D".equalsIgnoreCase(ocupBarco)) return 40;
        if (grupoEscala == 7 && "D".equalsIgnoreCase(ocupBarco)) return 45;
        if (grupoEscala == 8 && "D".equalsIgnoreCase(ocupBarco)) return 50;
        if (grupoEscala == 10 && "D".equalsIgnoreCase(ocupBarco)) return 55;
        if ((grupoEscala == 11 || grupoEscala == 14 || grupoEscala == 15 ||  grupoEscala == 17) && "D".equalsIgnoreCase(ocupBarco)) return 60;
        if (grupoEscala == 2 && "DA".equalsIgnoreCase(ocupBarco)) return 33;
        if (grupoEscala == 4 && "DA".equalsIgnoreCase(ocupBarco)) return 35;
        if (grupoEscala == 5 && "DA".equalsIgnoreCase(ocupBarco)) return 36;
        if (grupoEscala == 6 && "DA".equalsIgnoreCase(ocupBarco)) return 37;
        if (grupoEscala == 7 && "DA".equalsIgnoreCase(ocupBarco)) return 38;
        if (grupoEscala == 10 && "DA".equalsIgnoreCase(ocupBarco)) return 40;
        if (grupoEscala == 11 && "DA".equalsIgnoreCase(ocupBarco)) return 42;
        if (grupoEscala == 14 && "DA".equalsIgnoreCase(ocupBarco)) return 43;
        if (grupoEscala == 15 && "DA".equalsIgnoreCase(ocupBarco)) return 44;
        if (grupoEscala == 16 && "DA".equalsIgnoreCase(ocupBarco)) return 46;
        if (grupoEscala == 17 && "DA".equalsIgnoreCase(ocupBarco)) return 49;
        if (grupoEscala == 18 && "DA".equalsIgnoreCase(ocupBarco)) return 52;
        if ((grupoEscala == 19 || grupoEscala == 20) && "D".equalsIgnoreCase(ocupBarco)) return 54;
        if (grupoEscala == 21 && "DA".equalsIgnoreCase(ocupBarco)) return 57;
        if (grupoEscala == 22 && "DA".equalsIgnoreCase(ocupBarco)) return 60;
        System.out.println("Error: Combinacion de Grupo Escala y Ocupacion Barco no valida. Verifique los datos del trabajador");
        return 0;
    }
    
    double calcularPagoTotal() {
        return calcularPagoTotalHTrab() + calcularPagoTotalHExtra();
    }
    
    double calcularPagoTotalHExtra() {
       double PagoTotalHExtra = 0;
        for (Proyecto proyecto : proyectos){
            double calculo = proyecto.getHorasExtra() * tarifa;
            PagoTotalHExtra += calculo;
        }
        return PagoTotalHExtra;
    }
   
    double calcularPagoTotalHTrab() {
       double PagoTotalHTrab = 0;
        for (Proyecto proyecto : proyectos){
            double calculo = proyecto.getHorasTrab() * tarifa;
            PagoTotalHTrab += calculo;
        }
        return PagoTotalHTrab;
    }
   
    void mostrarProyectos() {
        System.out.println("--- Proyectos del trabajador ---");
        System.out.println("Total: " + proyectos.size());       
        for (Proyecto proyecto : proyectos) {
            System.out.print("Proyecto " + proyecto.getNumeroProyecto() + " -> Certificado: ");
            proyecto.certificado();
            System.out.println(" | Horas trabajadas: " + proyecto.getHorasTrab() + " | Pago por horas trabajadas: " + proyecto.getHorasTrab() * tarifa + " CUP | Horas extra: " + proyecto.getHorasExtra() + " | Pago por horas extra: " + proyecto.getHorasExtra() * tarifa + " CUP");            
        }
            System.out.println("-----------");
    }
    
void mostrarProyectosNoCertificados() {
    boolean tieneNoCertificados = false;
    for (Proyecto proyecto : proyectos) {
        if (!proyecto.isEsCertificado()) {
            if (!tieneNoCertificados) {
                System.out.println("Proyectos NO certificados:");
                tieneNoCertificados = true;
            }
            System.out.println("- Proyecto " + proyecto.getNumeroProyecto() + 
                " | Horas trabajadas: " + proyecto.getHorasTrab() + 
                " | Pago por horas trabajadas: " + (proyecto.getHorasTrab() * tarifa) + " CUP" +
                " | Horas extras: " + proyecto.getHorasExtra() + 
                " | Pago por horas extra: " + (proyecto.getHorasExtra() * tarifa) + " CUP");            
        }
    }
    if (!tieneNoCertificados) {
        System.out.println("El trabajador no tiene proyectos sin certificar.");
    }
}
    
    public double hallarCantTotalHExtra(){
        double totalHExtra = 0;
        for (Proyecto proyecto : proyectos){
            double calculo = proyecto.getHorasExtra();
            totalHExtra += calculo;
    }
        return totalHExtra;
    }
    
    public double hallarCantTotalHTrab() {
    double totalHTrab = 0;
    for (Proyecto proyecto : proyectos) {
        totalHTrab += proyecto.getHorasTrab();  // <- Cambiado de horasExtra a horasTrab
    }
    return totalHTrab;
}
    
    void mostrarInformacionCompleta() {
        System.out.println("--- Datos del Trabajador ---");
        System.out.println("Nombre: " + this.nombre);
        System.out.println("Departamento: " + this.depto);
        System.out.println("Codigo: " + this.codigo);
        System.out.println("Cargo: " + this.cargo);
        System.out.println("Grupo Escala: " + this.grupoEscala);
        System.out.println("Tarifa: " + this.tarifa);
        System.out.println("Cantidad total de horas trabajadas: " + this.hallarCantTotalHTrab()); 
        System.out.println("Pago total por horas trabajadas: " + this.calcularPagoTotalHTrab() + " CUP"); 
        System.out.println("Cantidad total de horas extras: " + this.hallarCantTotalHExtra());
        System.out.println("Pago total por horas extras: " + this.calcularPagoTotalHExtra() + " CUP");            
        System.out.println("Ocupacion Barco: " + this.ocupBarco);
        
        this.mostrarProyectos();
        
        System.out.print("Baja: ");
        this.Baja();
        
        this.Claves();
        
        System.out.println("Pago total por horas trabajadas y horas extras: " + this.calcularPagoTotal() + " CUP");
        System.out.println("Ultima modificacion: " + this.fechaUltimaModificacion);
    }
   
    void Baja() {
        System.out.println(esBaja ? "Si" : "No");
    }
       
    void Claves() {
        System.out.println(tieneClave269 ? "Tiene clave 269 " + "(" + getCantidadClaves269() + ")" : "No tiene clave 269");
        System.out.println(tieneClave271 ? "Tiene clave 271" : "No tiene clave 271");
        System.out.println(tieneClave278 ? "Tiene clave 278" : "No tiene clave 278");
    }

    public int getGrupoEscala() {
        return grupoEscala;
    }

    public void setGrupoEscala(int grupoEscala) {
        this.grupoEscala = grupoEscala;
    }

    public int getTarifa() {
        return tarifa;
    }

    public void setTarifa(int tarifa) {
        this.tarifa = tarifa;
    }

    public double getPagoTotal() {
        return pagoTotal;
    }

    public void setPagoTotal(double pagoTotal) {
        this.pagoTotal = pagoTotal;
    }

    public String getCargo() {
        return cargo;
    }

    public void setCargo(String cargo) {
        this.cargo = cargo;
    }

    public String getDepto() {
        return depto;
    }

    public void setDepto(String depto) {
        this.depto = depto;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getOcupBarco() {
        return ocupBarco;
    }

    public void setOcupBarco(String ocupBarco) {
        this.ocupBarco = ocupBarco;
    }

    public ArrayList<Proyecto> getProyectos() {
        return proyectos;
    }

    public void setProyectos(ArrayList<Proyecto> proyectos) {
        this.proyectos = proyectos;
    }

    public boolean isEsBaja() {
        return esBaja;
    }

    public void setEsBaja(boolean esBaja) {
        this.esBaja = esBaja;
    }

    public boolean isTieneClave271() {
        return tieneClave271;
    }

    public void setTieneClave271(boolean tieneClave271) {
        this.tieneClave271 = tieneClave271;
    }

    public boolean isTieneClave269() {
        return tieneClave269;
    }

    public void setTieneClave269(boolean tieneClave269) {
        this.tieneClave269 = tieneClave269;
    }

    public boolean isTieneClave278() {
        return tieneClave278;
    }

    public void setTieneClave278(boolean tieneClave278) {
        this.tieneClave278 = tieneClave278;
    }
    
    public String getFechaUltimaModificacion() {
        return fechaUltimaModificacion;
    }

    public void setFechaUltimaModificacion(String fechaUltimaModificacion) {
        this.fechaUltimaModificacion = fechaUltimaModificacion;
    }
}